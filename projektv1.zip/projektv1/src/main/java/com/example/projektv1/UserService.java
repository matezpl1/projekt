package com.example.projektv1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public Uzytkownik save(Uzytkownik user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepository.save(user);
    }

    public Uzytkownik findByLogin(String login) {
        Optional<Uzytkownik> user = userRepository.findByLogin(login);
        return user.orElse(null);
    }
    public boolean isLoginTaken(String login) {
        return userRepository.findByLogin(login).isPresent();
    }
    public List<Uzytkownik> findAll() {
        return userRepository.findAll();
    }
}
