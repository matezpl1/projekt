package com.example.projektv1;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;


@Entity
public class Uzytkownik {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Imię jest wymagane")
    @Pattern(regexp = "^[A-Z][a-z]{2,19}$", message = "Imię musi mieć od 3 do 20 znaków i zaczynać się wielką literą")
    private String firstName;

    @NotBlank(message = "Nazwisko jest wymagane")
    @Pattern(regexp = "^[A-Z][a-z]{2,49}$", message = "Nazwisko musi mieć od 3 do 50 znaków i zaczynać się wielką literą")
    private String lastName;

    @NotBlank(message = "Login jest wymagany")
    @Pattern(regexp = "^[a-z]{3,20}$", message = "Login musi mieć od 3 do 20 znaków i składać się z małych liter")
    @Column(unique = true)
    private String login;

    @NotBlank(message = "Hasło jest wymagane")
    @Size(min = 5, message = "Hasło musi mieć co najmniej 5 znaków")
    private String password;

    @Min(value = 18, message = "Wiek musi wynosić co najmniej 18 lat")
    private int age;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
    @Override
    public String toString() {
        return this.id.toString();
    }
}
