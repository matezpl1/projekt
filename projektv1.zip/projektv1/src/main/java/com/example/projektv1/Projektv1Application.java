package com.example.projektv1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projektv1Application {

    public static void main(String[] args) {
        SpringApplication.run(Projektv1Application.class, args);
    }

}
