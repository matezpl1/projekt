package com.example.projektv1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Controller
public class NotatkiController {

    @Autowired
    private NotatkiService notatkiService;

    @Autowired
    private KategoriaService kategoriaService;

    @Autowired
    private UserService userService;

    @GetMapping("/notatki")
    public String listNotatki(Model model) {
        model.addAttribute("notatki", notatkiService.findAll());
        return "notatki/list";
    }

    @GetMapping("/notatki/new")
    public String showNotatkiForm(Model model) {
        model.addAttribute("notatki", new Notatki());
        model.addAttribute("kategorie", kategoriaService.findAll());
        model.addAttribute("users", userService.findAll());
        return "notatki/form";
    }

    @PostMapping("/notatki")
    public String saveNotatki(@ModelAttribute("notatki") @Valid Notatki notatki, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("kategorie", kategoriaService.findAll());
            model.addAttribute("users", userService.findAll());
            return "notatki/form";
        }
        notatki.setDataDodania(LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        notatkiService.save(notatki);
        return "redirect:/notatki";
    }

    @GetMapping("/notatki/edit/{id}")
    public String showEditNotatkiForm(@PathVariable("id") Long id, Model model) {
        Notatki notatki = notatkiService.findById(id);
        if (notatki == null) {
            return "redirect:/notatki";
        }
        model.addAttribute("notatki", notatki);
        model.addAttribute("kategorie", kategoriaService.findAll());
        model.addAttribute("users", userService.findAll());
        return "notatki/form";
    }

    @PostMapping("/notatki/{id}")
    public String updateNotatki(@PathVariable("id") Long id, @ModelAttribute("notatki") @Valid Notatki notatki, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("kategorie", kategoriaService.findAll());
            model.addAttribute("users", userService.findAll());
            return "notatki/form";
        }
        Notatki existingNotatki = notatkiService.findById(id);
        if (existingNotatki != null) {
            notatki.setId(id);
            notatki.setDataDodania(existingNotatki.getDataDodania());
            notatkiService.save(notatki);
        }
        return "redirect:/notatki";
    }

    @GetMapping("/notatki/delete/{id}")
    public String deleteNotatki(@PathVariable("id") Long id) {
        notatkiService.deleteById(id);
        return "redirect:/notatki";
    }
}