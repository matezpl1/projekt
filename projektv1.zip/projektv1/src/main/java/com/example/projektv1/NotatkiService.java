package com.example.projektv1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotatkiService {

    @Autowired
    private NotatkiRepository notatkiRepository;

    public void deleteByKategoriaId(Long kategoriaId) {
        notatkiRepository.deleteByKategoriaId(kategoriaId);
    }

    public List<Notatki> findAll() {
        return notatkiRepository.findAll();
    }

    public Notatki findById(Long id) {
        return notatkiRepository.findById(id).orElse(null);
    }

    public void save(Notatki notatki) {
        notatkiRepository.save(notatki);
    }

    public void deleteById(Long id) {
        notatkiRepository.deleteById(id);
    }
}