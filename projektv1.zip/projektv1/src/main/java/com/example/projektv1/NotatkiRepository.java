package com.example.projektv1;

import org.springframework.data.jpa.repository.JpaRepository;

public interface NotatkiRepository extends JpaRepository<Notatki, Long> {
    void deleteByKategoriaId(Long kategoriaId);
}
