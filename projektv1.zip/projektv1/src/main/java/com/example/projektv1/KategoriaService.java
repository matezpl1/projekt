package com.example.projektv1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class KategoriaService {

    @Autowired
    private KategoriaRepository kategoriaRepository;

    public List<Kategoria> findAll() {
        return kategoriaRepository.findAll();
    }

    public Kategoria findById(Long id) {
        return kategoriaRepository.findById(id).orElse(null);
    }

    public void save(Kategoria kategoria) {
        kategoriaRepository.save(kategoria);
    }

    public void deleteById(Long id) {
        kategoriaRepository.deleteById(id);
    }
}

