package com.example.projektv1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@Controller
public class KategoriaController {

    @Autowired
    private KategoriaService kategoriaService;

    @GetMapping("/kategorie")
    public String listKategorie(Model model) {
        model.addAttribute("kategorie", kategoriaService.findAll());
        return "kategorie/list";
    }

    @GetMapping("/kategorie/new")
    public String showKategoriaForm(Model model) {
        model.addAttribute("kategoria", new Kategoria());
        return "kategorie/form";
    }

    @PostMapping("/kategorie")
    public String saveKategoria(@ModelAttribute("kategoria") @Valid Kategoria kategoria, BindingResult result) {
        if (result.hasErrors()) {
            return "kategorie/form";
        }
        kategoriaService.save(kategoria);
        return "redirect:/kategorie";
    }

    @GetMapping("/kategorie/edit/{id}")
    public String showEditKategoriaForm(@PathVariable("id") Long id, Model model) {
        Kategoria kategoria = kategoriaService.findById(id);
        if (kategoria == null) {
            return "redirect:/kategorie";
        }
        model.addAttribute("kategoria", kategoria);
        return "kategorie/form";
    }

    @PostMapping("/kategorie/{id}")
    public String updateKategoria(@PathVariable("id") Long id, @ModelAttribute("kategoria") @Valid Kategoria kategoria, BindingResult result) {
        if (result.hasErrors()) {
            return "kategorie/form";
        }
        Kategoria existingKategoria = kategoriaService.findById(id);
        if (existingKategoria != null) {
            kategoria.setId(id);
            kategoriaService.save(kategoria);
        }
        return "redirect:/kategorie";
    }

    @GetMapping("/kategorie/delete/{id}")
    public String deleteKategoria(@PathVariable("id") Long id) {
        kategoriaService.deleteById(id);
        return "redirect:/kategorie";
    }
}
